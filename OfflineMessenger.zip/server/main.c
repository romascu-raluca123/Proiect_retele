#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sqlite3.h>
#define PORT 2024
#define CLIENTS 5
#define BUFFER_SIZE 1024

struct {
    char user[BUFFER_SIZE];
    char password[BUFFER_SIZE];
}USERS;

struct {
    char id_client[BUFFER_SIZE];
    char userlogged[BUFFER_SIZE];
}LOGIN;
struct {
    char NR[1000][BUFFER_SIZE];
    char send_user[1000][BUFFER_SIZE];
    char MESSAGE[1000][BUFFER_SIZE];
    char receive_user[1000][BUFFER_SIZE];
    char READ[1000][BUFFER_SIZE];
    char TIME[1000][BUFFER_SIZE];
    char REPLY[1000][BUFFER_SIZE];
    char TIME_REPLY[1000][BUFFER_SIZE];
}MESSAGES;
int nr_messages=0;
void read_from_client(int client,char* message,int length)
{
    bzero(message,length);
    int readb=read(client,message,length);
    if(readb<0)
    {
        printf("[server]eroare la citire de la client.\n");
        if(close(client)==-1)
        { perror("eroare la inchidere client\n");
            exit(-1);
        }
    }
    else
    if(readb==0)
    {
        printf("client[%d] deconectat\n",client);
        char* err;           //il sterg din baza de date
        sqlite3 *db;

        if (sqlite3_open("bazaa.sqlite", &db)) {
            printf("eroare la deschiderea bazei de date\n");
            exit(-1);
        }
        char query[BUFFER_SIZE];
        bzero(query,sizeof(query));
        sprintf(query,"DELETE FROM LOGIN WHERE ID_CLIENT=%d;",client);
       // printf("[server] sterg din TABEL CLIENTULcu id ul:  %d, prin comanda : %s\n",client,query);

        int bd=sqlite3_exec(db,query,NULL,NULL,&err);
        if(bd!=SQLITE_OK)
        {
            printf("error: %s\n",err);
        }
        else
            printf("delete success\n");


        exit(-1);
    }
    //else
    //  printf("[server] am citit mesajul: %s\n",message);
}
void send_to_client(int client, char * answer,int length)
{
    int writeb=write(client,answer,length);
    if(writeb<0)
    {
        printf("[server]eroare la scriere catre client.\n");
        if(close(client)==-1)
        { perror("eroare la inchidere client\n");
            exit(-1);
        }
    }
    else
    if(writeb==0)
    {
        printf("[server]s-au scris 0 biti.\n");
        exit(-1);

    }
    //else
    //printf("[server] am scris mesajul: %s\n",answer);
}
//functia de callback pt baza de date

int callback_USERS(void *data, int argc, char **argv, char **azColName){

    for(int i = 0; i < argc; i++) {
        if(strcmp(azColName[i],"USER")==0)
            strcpy(USERS.user,argv[i]);
        else
            strcpy(USERS.password,argv[i]);  //show info from table
        printf("%s:%s\n",azColName[i],argv[i]);
    }
    printf("\n");
    return 0;
}

int callback_LOGIN(void *data, int argc, char **argv, char **azColName){

    strcpy(LOGIN.userlogged,"no");
    for(int i = 0; i < argc; i++) {
        if(strcmp(azColName[i],"ID_CLIENT")==0)
            strcpy(LOGIN.id_client,argv[i]);
        else
            strcpy(LOGIN.userlogged,argv[i]);
        printf("%s:%s\n",azColName[i],argv[i]);
    }
    printf("\n");
    return 0;
}
int callback_MESSAGES(void *data, int argc, char **argv, char **azColName){

    nr_messages++;
    int nr=nr_messages;
    for(int i = 0; i < argc; i++) {
        if(strcmp(azColName[i],"NUMBER")==0)
            strcpy(MESSAGES.NR[nr],argv[i]);
        if(strcmp(azColName[i],"send_user")==0)
            strcpy(MESSAGES.send_user[nr],argv[i]);
        else
        if(strcmp(azColName[i],"MESSAGE")==0)
            strcpy(MESSAGES.MESSAGE[nr],argv[i]);
        else
        if(strcmp(azColName[i],"receive_user")==0)
            strcpy(MESSAGES.receive_user[nr],argv[i]);
        else
        if(strcmp(azColName[i],"READ")==0)
            strcpy(MESSAGES.READ[nr],argv[i]);
        else
        if(strcmp(azColName[i],"TIME")==0)
            strcpy(MESSAGES.TIME[nr],argv[i]);
        else
        if(strcmp(azColName[i],"REPLY")==0)
            strcpy(MESSAGES.REPLY[nr],argv[i]);
        else
        if(strcmp(azColName[i],"TIME_REPLY")==0)
            strcpy(MESSAGES.TIME_REPLY[nr],argv[i]);
        printf("%s:%s\n",azColName[i],argv[i]);
    }
    printf("\n");
    return 0;
}
int islogged(int client, sqlite3* db, char* userlogg)
{
    bzero(LOGIN.id_client,sizeof (LOGIN.id_client));
    bzero(LOGIN.userlogged,sizeof (LOGIN.userlogged));
    char* err;
    char query[BUFFER_SIZE];
    bzero(query,sizeof(query));
    sprintf(query,"SELECT * FROM LOGIN WHERE ID_CLIENT=%d;",client);
    //printf("[server] SELECTEZ clientul si userul corespunzator daca s a logat\n");

    int bd=sqlite3_exec(db,query,callback_LOGIN,NULL,&err);
    if(bd!=SQLITE_OK)
    {
        printf("error: %s\n",err);
    }
    else {
        printf("select success\n");
    }
    //printf("id ul gasit e  : %s si userul: %s\n",LOGIN.id_client,LOGIN.userlogged);
    if(strcmp(LOGIN.userlogged,"no")==0)
        return 0;
    else
    {     int length=sizeof(userlogg);
        bzero(userlogg,length);
        strcpy(userlogg,LOGIN.userlogged);
        return 1;
    }
}
// int userislogged(sqlite3* db, char* user)  //returneaza id-ul clientului pe care e logat userul dorit
// {
//     bzero(LOGIN.id_client,sizeof (LOGIN.id_client));
//     bzero(LOGIN.userlogged,sizeof(LOGIN.userlogged));
//     char* err;
//     char query[BUFFER_SIZE];
//     bzero(query,sizeof(query));
//     sprintf(query,"SELECT * FROM LOGIN WHERE USER='%s';",user);
//     //printf("[server] SELECTEZ clientul si userul corespunzator daca s a logat\n");

//     int bd=sqlite3_exec(db,query,callback_LOGIN,NULL,&err);
//     if(bd!=SQLITE_OK)
//     {
//         printf("error: %s\n",err);
//     }
//     else {
//         printf("select success\n");
//     }
//     //printf("id ul gasit e  : %s si userul: %s\n",LOGIN.id_client,LOGIN.userlogged);
//     int id=atoi(LOGIN.id_client);
//     printf("id ul e: %d\n",id);
//     return id;
// } 
int user_exist(sqlite3* db,char* user, char* password){  
    char query[BUFFER_SIZE];
    char* err;
    bzero(USERS.user,sizeof (USERS.user));
    bzero(USERS.password,sizeof (USERS.password));
    bzero(query,sizeof(query));
    sprintf(query,"SELECT * FROM USERS WHERE USER='%s';",user);
   // printf("[server] SELECTEZ userii cu userul %s adica daca mi da cv sau nu\n",user);

    int bd;
    bd=sqlite3_exec(db,query,callback_USERS,NULL,&err);
    if(bd!=SQLITE_OK)
    {
        printf("error: %s\n",err);
    }
    else {
        printf("select success\n");
    }
    //printf("userul gasit in baza de date e : %s si parola: %s\n",USERS.user,USERS.password);
    if(strcmp(USERS.user,user)==0)
    { int length=sizeof(password);
        bzero(password,length);
        strcpy(password,USERS.password);
        return 1;
    }
    else
        return 0;

}

void Register(int client,sqlite3* db)
{
    char user[BUFFER_SIZE];
    char password[BUFFER_SIZE];
    char answer[BUFFER_SIZE];

    char* err;
    bzero(answer,sizeof(answer));
    strcpy(answer,"user: ");
    send_to_client(client,answer,sizeof(answer));

    bzero(user,sizeof(user));
    read_from_client(client,user,sizeof(user));
    //caut user ul sa vad daca nu exista deja in baza de date
    if(user_exist(db,user,password)!=0)  
    {
        bzero(answer,sizeof(answer));
        strcpy(answer,"Userul exista deja in baza de date. Incercati din nou comanda register.");
        send_to_client(client,answer,sizeof(answer));
    }
    else
    {
        char query[BUFFER_SIZE];
        bzero(answer,sizeof(answer));
        strcpy(answer,"User valid. Introduceti o parola:");
        send_to_client(client,answer,sizeof(answer));

        bzero(password,sizeof(password));
        read_from_client(client,password,sizeof(password));
//bagi in tabel noul user cu parola

        bzero(query,sizeof(query));
        sprintf(query,"INSERT INTO USERS VALUES('%s','%s');",user,password);
        //printf("[server] Inregistrez utilizatorul : %s, prin comanda : %s\n",user,query);

        int bd=sqlite3_exec(db,query,NULL,NULL,&err);
        if(bd!=SQLITE_OK)
        {
            printf("error: %s\n",err);
        }
        else {
            printf("insert success\n");
            bzero(answer, sizeof(answer));
            strcpy(answer, "Utilizator inregistrat.");
            send_to_client(client, answer, sizeof(answer));
        }
    }
}
void login(int client, sqlite3* db)
{
    char user[BUFFER_SIZE];
    char password[BUFFER_SIZE];
    char pass[BUFFER_SIZE];
    // char confirm[10];
    char answer[BUFFER_SIZE];
    char userlogg[BUFFER_SIZE];
    if (islogged(client, db,userlogg) != 0)
    {
        bzero(answer, sizeof(answer));
        sprintf(answer, "Sunteti deja logat pe contul : %s", userlogg);
        send_to_client(client, answer, sizeof(answer));
    }
    else
    {
        bzero(answer, sizeof(answer));
        strcpy(answer, "User:");
        send_to_client(client, answer, sizeof(answer));

        bzero(user, sizeof(user));
        read_from_client(client, user, sizeof(user));

        if (user_exist(db, user, password) == 0) {
            bzero(answer, sizeof(answer));
            strcpy(answer, "User-ul nu se gaseste in baza de date. Va puteti inregistra cu comanda <register>");
            send_to_client(client, answer, sizeof(answer));
        }
         else
        {
            bzero(answer, sizeof(answer));
            strcpy(answer, "User valid. Introduceti parola: ");
            send_to_client(client, answer, sizeof(answer));

            bzero(pass, sizeof(pass));
            read_from_client(client, pass, sizeof(pass));

            if (strcmp(password, pass) != 0) {
                bzero(answer, sizeof(answer));
                strcpy(answer, "Parola este gresita. Mai aveti o incercare.Introduceti parola:");
                send_to_client(client, answer, sizeof(answer));

                bzero(pass, sizeof(pass));
                read_from_client(client, pass, sizeof(pass));

                if (strcmp(password, pass) != 0) {
                    bzero(answer, sizeof(answer));
                    strcpy(answer, "Logare esuata.");
                    send_to_client(client, answer, sizeof(answer));
                } else {
                    char query[BUFFER_SIZE];
                    char *err;

                    bzero(query, sizeof(query));
                    sprintf(query, "UPDATE LOGIN SET USER='%s' WHERE ID_CLIENT='%d';", user, client);
                    //printf("[server] loghez utilizatorul : %s, prin comanda : %s\n", user, query);

                    int bd = sqlite3_exec(db, query, NULL, NULL, &err);
                    if (bd != SQLITE_OK) {
                        printf("error: %s\n", err);
                    } else {
                        printf("insert succes\n");
                        bzero(answer, sizeof(answer));
                        strcpy(answer, "Logare efectuata cu succes.");
                        send_to_client(client, answer, sizeof(answer));
                    }
                }
            }
             else
             {
                char query[BUFFER_SIZE];
                char *err;
                bzero(query, sizeof(query));
                sprintf(query, "UPDATE LOGIN SET USER='%s' WHERE ID_CLIENT='%d';", user, client);
                //printf("[server] loghez utilizatorul : %s, prin comanda : %s\n", user, query);

                int bd = sqlite3_exec(db, query, NULL, NULL, &err);
                if (bd != SQLITE_OK) 
                {
                    printf("error: %s\n", err);
                } 
                else 
                {
                    printf("insert succes\n");
                    bzero(answer, sizeof(answer));
                    strcpy(answer, "logare efectuata cu succes");
                    send_to_client(client, answer, sizeof(answer));
                }
             }

        }
    }
}

void quit(int client, sqlite3* db)
{
    send_to_client(client,"quit",sizeof("quit"));
    printf("client[%d]-deconectat\n",client);
    char *err;
    char query[BUFFER_SIZE];
    bzero(query,sizeof(query));
    sprintf(query,"DELETE FROM LOGIN WHERE ID_CLIENT=%d;",client);
    //printf("[server] sterg din TABEL CLIENTULcu id ul:  %d, prin comanda : %s\n",client,query);

    int bd=sqlite3_exec(db,query,NULL,NULL,&err);
    if(bd!=SQLITE_OK)
    {
        printf("error: %s\n",err);
    }
    else
        printf("delete success\n");


    if(sqlite3_close(db)!=SQLITE_OK)
    {
        printf("[server]: eroare la inchiderea bazei de date");
        exit(-1);
    }
    exit(0);
}
void logout(int client,sqlite3* db)
{

    char userlogg[BUFFER_SIZE];
    if (islogged(client, db,userlogg) == 0)
        send_to_client(client, "Nu sunteti logat", sizeof("Nu sunteti logat"));
    else 
    {
        char query[BUFFER_SIZE];
        char *err;
        bzero(query, sizeof(query));
        sprintf(query, "UPDATE LOGIN SET USER='no' WHERE ID_CLIENT='%d';", client);
        //printf("[server] deloghez clientul :%d, prin comanda : %s\n", client, query);

        int bd = sqlite3_exec(db, query, NULL, NULL, &err);
        if (bd != SQLITE_OK) {
            printf("error: %s\n", err);
        } 
        else 
        {
            printf("update success\n");
            send_to_client(client, "delogare efectuata cu succes",
                           sizeof("delogare efectuata cu succes"));
        }
    }
}
void sendmsgto(int client,sqlite3* db, char *recv_user){
    char send_user[BUFFER_SIZE];
    char password[BUFFER_SIZE];
    char answer[BUFFER_SIZE];
    if(islogged(client,db,send_user)==0) {
        bzero(answer, sizeof(answer));
        strcpy(answer, "Nu sunteti logat");
        send_to_client(client, answer, sizeof(answer));
    }
    else
    {
        if(user_exist(db,recv_user,password)==0) {
            bzero(answer, sizeof(answer));
            strcpy(answer, "Userul nu exista in baza de date.");
            send_to_client(client, answer, sizeof(answer));
        }
        else
            {
                bzero(answer, sizeof(answer));
                strcpy(answer, "Introduceti mesajul:");
                send_to_client(client, answer, sizeof(answer));
                char msg[BUFFER_SIZE];
                bzero(msg,sizeof(msg));
                read_from_client(client,msg,sizeof(msg));

                char* err;
                char query[BUFFER_SIZE];
                bzero(query,sizeof (query));
                sprintf(query,"INSERT INTO MESSAGES (send_user, MESSAGE,receive_user,READ,TIME) VALUES('%s','%s','%s','no',datetime('now','localtime'));",send_user,msg,recv_user);
               // printf("[server] Inserez mesajul in tabel prin comanda : %s\n",query);

                int bd=sqlite3_exec(db,query,NULL,NULL,&err);
                if(bd!=SQLITE_OK)
                {
                    printf("error: %s\n",err);
                }
                else {
                    printf("insert success\n");
                    bzero(answer,sizeof(answer));
                    strcpy(answer,"Successful send.");
                    send_to_client(client,answer,sizeof(answer));
                }
            }
    }

} 
void seehistoryconvwith(int client, sqlite3* db, char *recv_user)
{
    char send_user[BUFFER_SIZE];
    char password[BUFFER_SIZE];
    char answer[BUFFER_SIZE];
    if(islogged(client,db,send_user)==0)
        send_to_client(client,"nu sunteti logat",sizeof("nu sunteti logat"));
    else
    {
        if(user_exist(db,recv_user,password)==0)
            send_to_client(client,"user-ul introdus nu exista in baza de date",sizeof("user-ul introdus nu exista in baza de date"));
        else
        {
           // printf("o sa citesc conv user ului %s cu : %s \n", send_user, recv_user);
//pregatesc structura globala
            for(int i=0;i<=1000;i++)
            {
                bzero(MESSAGES.send_user[i],sizeof(MESSAGES.send_user[i]));
                bzero(MESSAGES.MESSAGE[i],sizeof(MESSAGES.MESSAGE[i]));
                bzero(MESSAGES.receive_user[i],sizeof(MESSAGES.receive_user[i]));
                bzero(MESSAGES.READ[i],sizeof(MESSAGES.READ[i]));
                bzero(MESSAGES.TIME[i],sizeof(MESSAGES.TIME[i]));
                bzero(MESSAGES.REPLY[i],sizeof(MESSAGES.REPLY[i]));
                bzero(MESSAGES.TIME_REPLY,sizeof(MESSAGES.TIME_REPLY[i]));
            }
            nr_messages=0;
//pregatesc baza de date
            char* err;
            char query[BUFFER_SIZE];
            bzero(query,sizeof(query));
            sprintf(query,"SELECT * FROM MESSAGES WHERE (send_user='%s' AND receive_user='%s') OR (send_user='%s' AND receive_user='%s');",send_user,recv_user,recv_user,send_user);
            //printf("am comanda %s",query);
            int bd=sqlite3_exec(db,query,callback_MESSAGES,NULL,&err);
            if(bd!=SQLITE_OK)
            {
                printf("error: %s\n",err);
            }
            else
            {
                printf("select success\n");
            }
            char mesaj[BUFFER_SIZE];
            bzero(answer, sizeof(answer));
            sprintf(answer,"HISTORY CONVERSATION with %s:\n",recv_user);
            
            for (int i = 1; i <= nr_messages; i++)
            {
                  printf("nr:%s senduser %s message: %s recvuser %s read: %s time: %s reply: %s timereply %s\n",
                      MESSAGES.NR[i], MESSAGES.send_user[i], MESSAGES.MESSAGE[i], MESSAGES.receive_user[i],
                      MESSAGES.READ[i], MESSAGES.TIME[i], MESSAGES.REPLY[i], MESSAGES.TIME_REPLY[i]);
                bzero(mesaj,sizeof(mesaj));

                if(strcmp(MESSAGES.REPLY[i],"no")==0)
                    sprintf(mesaj,"%s.from [%s] to [%s]     at %s:\n<%s>\n",MESSAGES.NR[i],MESSAGES.send_user[i],MESSAGES.receive_user[i],MESSAGES.TIME[i],MESSAGES.MESSAGE[i]);
                else
                    sprintf(mesaj,"%s.from [%s] to [%s]     at %s:\n<%s>\n>>>Reply from [%s]     at %s:\nR:<%s>\n",MESSAGES.NR[i],MESSAGES.send_user[i],MESSAGES.receive_user[i],MESSAGES.TIME[i],MESSAGES.MESSAGE[i],MESSAGES.receive_user[i],MESSAGES.TIME_REPLY[i],MESSAGES.REPLY[i]);

                strcat(answer,mesaj);
            }
            //printf("trimit: %s",answer);
            //strcpy(answer, "formez answer si trimit noile mesaje");
            send_to_client(client, answer, sizeof(answer));
        }
    }
}
void seenewmessages(int client, sqlite3* db){
    char send_user[BUFFER_SIZE];
    char answer[BUFFER_SIZE];
    if(islogged(client,db,send_user)==0) {
        bzero(answer, sizeof(answer));
        strcpy(answer, "Nu sunteti logat.");
        send_to_client(client, answer, sizeof(answer));
    }
    else
    {
//pregatesc structura globala
        for(int i=0;i<=1000;i++)
        {
            bzero(MESSAGES.send_user[i],sizeof(MESSAGES.send_user[i]));
            bzero(MESSAGES.MESSAGE[i],sizeof(MESSAGES.MESSAGE[i]));
            bzero(MESSAGES.receive_user[i],sizeof(MESSAGES.receive_user[i]));
            bzero(MESSAGES.READ[i],sizeof(MESSAGES.READ[i]));
            bzero(MESSAGES.TIME[i],sizeof(MESSAGES.TIME[i]));
            bzero(MESSAGES.REPLY[i],sizeof(MESSAGES.REPLY[i]));
            bzero(MESSAGES.TIME_REPLY,sizeof(MESSAGES.TIME_REPLY[i]));
        }
        nr_messages=0;
//pregatesc baza de date
        char* err;
        char query[BUFFER_SIZE];
        bzero(query,sizeof(query));
        sprintf(query,"SELECT * FROM MESSAGES WHERE receive_user='%s' AND READ='no';",send_user);
        //printf("am comanda %s",query);
        int bd=sqlite3_exec(db,query,callback_MESSAGES,NULL,&err);
        if(bd!=SQLITE_OK)
        {
            printf("error: %s\n",err);
        }
        else {
            printf("select success\n");
        }
        if(nr_messages==0)
        {
            bzero(answer, sizeof(answer));
            strcpy(answer, "Nu aveti mesaje noi.");
            send_to_client(client, answer, sizeof(answer));
        }
        else
        {   char mesaj[BUFFER_SIZE];  

                  bzero(answer, sizeof(answer));
                strcpy(answer,"New messages:\n");
            for (int i = 1; i <= nr_messages; i++)
              {  printf("nr:%s senduser %s message: %s recvuser %s read: %s time: %s reply: %s timereply %s\n",
                       MESSAGES.NR[i], MESSAGES.send_user[i], MESSAGES.MESSAGE[i], MESSAGES.receive_user[i],
                       MESSAGES.READ[i], MESSAGES.TIME[i], MESSAGES.REPLY[i], MESSAGES.TIME_REPLY[i]);

                    bzero(mesaj,sizeof(mesaj));
                    sprintf(mesaj,"%s.[%s]:%s     at %s\n",MESSAGES.NR[i],MESSAGES.send_user[i],MESSAGES.MESSAGE[i],MESSAGES.TIME[i]);
                    strcat(answer,mesaj);
                }
               // printf("trimit: %s",answer);
            strcat(answer,"Daca doriti sa raspundeti la un anumit mesaj introduceti comanda <reply at : <nr> >.");
            send_to_client(client, answer, sizeof(answer));
//update in db read  no>>>yes
            bzero(query, sizeof(query));
            sprintf(query, "UPDATE MESSAGES SET READ='yes' WHERE receive_user='%s' AND READ='no';", send_user);
            //printf("am comanda %s",query);
            bd=sqlite3_exec(db,query,NULL,NULL,&err);
            if(bd!=SQLITE_OK)
            {
                printf("error: %s\n",err);
            }
            else {
                printf("update success\n");
            }
        }
    }
}
void reply(int client,sqlite3* db,int nr) {
    char send_user[BUFFER_SIZE];
    char answer[BUFFER_SIZE];
    char reply_msg[BUFFER_SIZE];
    if (islogged(client, db, send_user) == 0) {
        bzero(answer, sizeof(answer));
        strcpy(answer, "Nu sunteti logat");
        send_to_client(client, answer, sizeof(answer));
    } else {
        bzero(answer, sizeof(answer));
        strcpy(answer, "Introduceti mesajul:");
        send_to_client(client, answer, sizeof(answer));

        bzero(reply_msg, sizeof(reply_msg));
        read_from_client(client, reply_msg, sizeof(reply_msg));

        char *err;
        char query[BUFFER_SIZE];
        bzero(query, sizeof(query));
        sprintf(query,
                "UPDATE MESSAGES SET REPLY='%s',TIME_REPLY=datetime('now','localtime') WHERE NUMBER=%d;",
                reply_msg, nr);
        //printf("[server] Inserez mesajul in tabel prin comanda : %s\n", query);

        int bd = sqlite3_exec(db, query, NULL, NULL, &err);
        if (bd != SQLITE_OK) {
            printf("error: %s\n", err);
        } else {
            printf("insert success\n");
            bzero(answer, sizeof(answer));
            strcpy(answer, "successful reply.");
            send_to_client(client, answer, sizeof(answer));
        }
    }
}
void seemyhistory(int client,sqlite3* db)//toate mesajele tirmise de mine
{
    char send_user[BUFFER_SIZE];
    char answer[BUFFER_SIZE];
    if(islogged(client,db,send_user)==0)
        send_to_client(client,"nu sunteti logat",sizeof("nu sunteti logat"));
    else
    {
       // printf("o sa citesc toate mesajele trimise de user ul %s  \n", send_user);
//pregatesc structura globala
        for(int i=0;i<=1000;i++)
        {
            bzero(MESSAGES.send_user[i],sizeof(MESSAGES.send_user[i]));
            bzero(MESSAGES.MESSAGE[i],sizeof(MESSAGES.MESSAGE[i]));
            bzero(MESSAGES.receive_user[i],sizeof(MESSAGES.receive_user[i]));
            bzero(MESSAGES.READ[i],sizeof(MESSAGES.READ[i]));
            bzero(MESSAGES.TIME[i],sizeof(MESSAGES.TIME[i]));
            bzero(MESSAGES.REPLY[i],sizeof(MESSAGES.REPLY[i]));
            bzero(MESSAGES.TIME_REPLY,sizeof(MESSAGES.TIME_REPLY[i]));
        }
        nr_messages=0;
//pregatesc baza de date
        char* err;
        char query[BUFFER_SIZE];
        bzero(query,sizeof(query));
        sprintf(query,"SELECT * FROM MESSAGES WHERE send_user='%s';",send_user);
        //printf("am comanda %s",query);
        int bd=sqlite3_exec(db,query,callback_MESSAGES,NULL,&err);
        if(bd!=SQLITE_OK)
        {
            printf("error: %s\n",err);
        }
        else
        {
            printf("select success\n");
        }
        char mesaj[BUFFER_SIZE];
        bzero(answer, sizeof(answer));
        strcpy(answer,"MY HISTORY:\n");
        for (int i = 1; i <= nr_messages; i++)
        {  printf("nr:%s senduser %s message: %s recvuser %s read: %s time: %s reply: %s timereply %s\n",
                  MESSAGES.NR[i], MESSAGES.send_user[i], MESSAGES.MESSAGE[i], MESSAGES.receive_user[i],
                  MESSAGES.READ[i], MESSAGES.TIME[i], MESSAGES.REPLY[i], MESSAGES.TIME_REPLY[i]);
            bzero(mesaj,sizeof(mesaj));
            sprintf(mesaj,"%s.%s     to:[%s]    at %s\n",MESSAGES.NR[i],MESSAGES.MESSAGE[i],MESSAGES.receive_user[i],MESSAGES.TIME[i]);
            strcat(answer,mesaj);
        }
       // printf("trimit: %s",answer);
        send_to_client(client, answer, sizeof(answer));
    }
}

void interpret_command( int client, char * message,sqlite3 *db)
{
    if(strcmp(message,"register")==0)
    {
        Register(client,db);
    }
    else

    if(strcmp(message,"login")==0)
    {
        login(client,db);
    }
    else

    if(strcmp(message,"quit")==0)
    {
        quit(client,db);
    }

    else
    if (strcmp(message,"help")==0)
    {
        send_to_client(client,"Comenzile disponibile daca nu sunteti logat sunt:\n<register>\n<login>\n<help>\n<quit>\n\nDaca sunteti logat puteti apela comenzile:\n<send message to : <user> >\n<see new messages>\n<see history conversation with : <user> >\n<see my history>\n<logout>\n<quit>\n",sizeof("Comenzile disponibile daca nu sunteti logat sunt:\n<register>\n<login>\n<help>\n<quit>\n\nDaca sunteti logat puteti apela comenzile:\n<send message to : <user> >\n<see new messages>\n<see history conversation with : <user> >\n<see my history>\n<logout>\n<quit>\n"));
    }
    else
    if(strcmp(message,"see new messages")==0)
    {
        seenewmessages(client,db);
    }
    else
        if(strncmp(message,"reply at : ",10)==0)
        {
            char number[10];
            bzero(number,sizeof(number));
            strcpy(number,message+11);
            int nr;
            nr=atoi(number);
            reply(client,db,nr);
        }
        else
        if(strncmp(message,"send message to : ",17)==0)
        {
            char recv_user[BUFFER_SIZE];
            bzero(recv_user,sizeof(recv_user));
            strcpy(recv_user,message+18);
            sendmsgto(client,db,recv_user);

        }
        else
        if(strncmp(message,"see history conversation with : ",31)==0)
        {
            char recv_user[BUFFER_SIZE];
            bzero(recv_user,sizeof(recv_user));
            strcpy(recv_user,message+32);
            seehistoryconvwith(client,db,recv_user);
        }
        else
        if(strcmp(message,"see my history")==0)
        {
            seemyhistory(client,db);
        }
        else
        if(strcmp(message,"logout")==0) {
            logout(client,db);
        }
        else
        {
            char answer[BUFFER_SIZE];
            bzero(answer,sizeof(answer));
            strcpy(answer,"Ati introdus o comanda invalida. Pentru ajutor apelati <help>");
            send_to_client(client,answer,sizeof(answer));
        }
}
int main() {

    int sd;
    struct sockaddr_in server;
    struct sockaddr_in from;

    sd = socket(AF_INET, SOCK_STREAM, 0);
    if (sd == -1) {
        perror("[server]:eroare la socket().\n");
        return errno;
    }
//pregatesc structurile de date
    bzero(&server, sizeof(server));
    bzero(&from, sizeof(from));

//umplu structura folostia de socket
    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    server.sin_addr.s_addr = htonl(INADDR_ANY);

//atasez socketul
    if (bind(sd, (struct sockaddr *) &server, sizeof(struct sockaddr)) == -1) {
        perror("[server]:Eroare la bind().\n");
        return errno;
    }
//pun serverul sa asculte
    if (listen(sd, CLIENTS) == -1) {
        perror("[server]Eroare la listen().\n");
        return errno;
    }

    printf("server initializat cu succes.\n");

    while(1)
    {
        //accept clientul
        int client;
        int length = sizeof(from);
        bzero(&from, sizeof(from));
        client = accept(sd, (struct sockaddr *) &from, &length);
        if (client < 0) {
            perror("[server]Eroare la accept().\n");
        }
        pid_t child;
        child=fork();
        if(child==-1)
        {
            perror("[server]: Eroare la fork().\n");
        }
        if(child==0)
        {
            //child process
            printf("child process.\n");
            char message[BUFFER_SIZE];


//deschid baza de date
            char* err;
            sqlite3 *db;

            if (sqlite3_open("bazaa.sqlite", &db)) {
                printf("eroare la deschiderea bazei de date\n");
                return 0;
            }

//introduc in tabelul login din baza de date clientul cu id client

            char query[BUFFER_SIZE];
            bzero(query,sizeof(query));
            sprintf(query,"INSERT INTO LOGIN (ID_CLIENT) VALUES('%d');",client);
            //printf("[server] Introduc IN TABEL CLIENTUL NOU cu id ul:  %d, prin comanda : %s\n",client,query);

            int bd=sqlite3_exec(db,query,NULL,NULL,&err);
            if(bd!=SQLITE_OK)
            {
                printf("error: %s\n",err);
            }
            else
                printf("insert success\n");

            while(1)
            {
                read_from_client(client, message,sizeof(message));

                interpret_command(client,message,db);
            }

        }
        // else
        // {
        //     printf("parent process.\n");
        // }
    }
}
