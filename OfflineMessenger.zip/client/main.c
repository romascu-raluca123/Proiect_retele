#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#define PORT 2024
#define BUFFER_SIZE 1024

void read__command(char * command,int length)
{
         bzero(command,length);
        int readb=read(0,command,length-1);
        if(readb<=0) {
            printf("[client] eroare la citirea comenzii");
            exit(-1);
        }
        else
        {
        command[strlen(command)-1]=NULL;
        }
}
void send_to_server(int server,char* command, int length)
{
        int writeb=write(server,command, length);
        if(writeb<=0)
            {
                printf("[client] eroare la scriere catre server.\n");
                exit(-1);
            }
}
void read_from_server(int server, char* answer, int length)
{
        bzero(answer,length);
       int readb=read(server,answer,length);
        if(readb<=0)
           {
                printf("[client] eroare la citire de la server.\n");
                exit(-1);
           }
           else
             {
                 printf("%s\n",answer);
                 if(strncmp(answer,"quit",4)==0)
                 {
                     printf("DECONECTARE\n");
                     exit(0);
                 }
             }

}
int main ()
{
    int sd;
    struct sockaddr_in server;

//creez socketul
    sd=socket(AF_INET, SOCK_STREAM, 0);
    if(sd==-1)
    {
        perror("[client]:eroare la socket().\n");
        return errno;
    }
//umplu structura folosita de socket
    server.sin_family=AF_INET;
    server.sin_port= htons(PORT);
    server.sin_addr.s_addr= htonl(INADDR_ANY);

//ma conectez la server
    if(connect(sd,(struct sockaddr*)&server,sizeof(struct sockaddr))==-1)
    {
        perror("[client]: eroare la connect().\n");
        return errno;
    }
    printf("Conexiune realizata cu succes!.\n Pentru a vedea comenzile disponibile, tastati <help>.\nIntroduceti comanda dorita:\n");
    fflush(stdout);
    char command[BUFFER_SIZE];
    char answer[BUFFER_SIZE];
   
    while(1)
    {
        read__command(command,sizeof(command));

        send_to_server(sd,command,sizeof(command));

        read_from_server(sd,answer,sizeof(answer));

    }


    return 0;
}